#include<stdio.h>
int main()
{
    int a[] = { 10, 20, 30, 40, 50} ;
    int *ptr;
    ptr = a;
    printf("%d\n ", (*ptr)*3);
    //printf("%d\n ", *(ptr+3));
    return 0;
}
