#include<stdio.h>
int main()
{
    char arr[4][40];
    char *p =
    { "array of c string",
        "is fun to use",
        "make sure to properly",
        "tell the array size"
    };
    arr=p;
    for (int i = 0; i < 5; i++)
    {
        printf("'%s' has length %d\n", arr[i], strlen(arr[i]));

    }
    return 0;
}
