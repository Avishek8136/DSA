#include <stdio.h>
int main()
{
    char a[]="Namaste";
    char *s;
    s=a;
    printf("Size is :\n %d\n%d\n", sizeof(s),sizeof(a));
    printf("%s\n",a);
    printf("%c ",*s);
    printf("\n%c",*(s+1));
    return 0;
}
