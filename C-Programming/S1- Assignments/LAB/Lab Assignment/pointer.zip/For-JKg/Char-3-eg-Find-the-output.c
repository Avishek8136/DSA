#include<stdio.h>
#include<string.h>
int main()
{
    int i=0;
    char *s = "Namaste";
    for(i=0;i<10;i++)
    {
        printf("%c",*s);
        s++;
    }
    return 0;
}
