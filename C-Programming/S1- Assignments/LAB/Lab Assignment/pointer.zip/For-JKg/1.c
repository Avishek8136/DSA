#include <stdio.h>
int main ()
{
   int  a;
   char b[10]={'a','b','c'};
   printf("Address of 'b' : %d\n", &b );
   printf("Address of 'b[0]' : %d\n", &b[0]);
   printf("Address of 'b[1]' : %d\n", &b[1]);
    printf("Address of 'b[5]' : %d\n", &b[5]);
   return 0;
}
