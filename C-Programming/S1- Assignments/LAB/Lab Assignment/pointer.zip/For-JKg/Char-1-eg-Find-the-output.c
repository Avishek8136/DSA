#include<stdio.h>
int main()
{
    int i=0;
    char a[] = "Namaste everyone";
    char *p;
    p=a;
    printf("%c",*p);
    for(i=1;i<sizeof(a);i++)
    {
        printf("%c",*(p+1));
    }
    return 0;
}
