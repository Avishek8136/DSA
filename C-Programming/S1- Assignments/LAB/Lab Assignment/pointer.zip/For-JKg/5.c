#include <stdio.h>
int main ()
{
   char a = 'v';
   char *b;
   b = &a;
   printf("%d\n",b);
   b++;
   b++;
   printf("%d",b);
   return 0;
}

