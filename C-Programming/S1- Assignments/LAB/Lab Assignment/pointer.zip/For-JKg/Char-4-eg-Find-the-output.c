#include<stdio.h>
int main()
{
    char arr[4][40] =
    { "array of c string",
        "is fun to use",
        "make sure to properly",
        "tell the array size"
    };
char *p = arr;
    for (int i = 0; i < 100; i++)
    {
        printf("%c",*p );
        p++;
    }
    return 0;
}

